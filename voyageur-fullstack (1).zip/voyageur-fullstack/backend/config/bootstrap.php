<?php
/**
 * Bootstrap commun à tous les endpoints de l'API.
 */

// --- Session (auth) ---
session_start();

// --- CORS (à restreindre en production) ---
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once __DIR__ . '/database.php';

/** Lit et décode le corps JSON de la requête */
function getJsonBody(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

/** Réponse JSON standardisée */
function respond($data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function respondError(string $message, int $code = 400): void {
    respond(['success' => false, 'error' => $message], $code);
}

function requireAuth(): array {
    if (empty($_SESSION['user_id'])) {
        respondError('Non authentifié. Veuillez vous connecter.', 401);
    }
    return ['id' => $_SESSION['user_id'], 'email' => $_SESSION['user_email'] ?? null];
}
