<?php
/**
 * Connexion à la base de données MySQL (PDO)
 *
 * ⚠️ Ce fichier est un MODÈLE (versionné sur GitHub).
 * Copiez-le vers `database.php` (ignoré par git) et renseignez vos propres
 * identifiants :
 *
 *   cp backend/config/database.example.php backend/config/database.php
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'voyageur_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'error' => 'Connexion base de données échouée: ' . $e->getMessage()]);
            exit;
        }
    }
    return $pdo;
}
