<?php
/**
 * GET    /api/plans.php          -> liste des plans sauvegardés de l'utilisateur
 * POST   /api/plans.php   body:{title?, destinations, depart_date, retour_date,
 *                                travelers, trip_type, budget_level, total_price, details}
 * DELETE /api/plans.php?id=1     -> supprimer un plan
 */

require_once __DIR__ . '/../config/bootstrap.php';

$db   = getDB();
$user = requireAuth();

switch ($_SERVER['REQUEST_METHOD']) {

    case 'GET':
        $stmt = $db->prepare('SELECT * FROM saved_plans WHERE user_id = :uid ORDER BY created_at DESC');
        $stmt->execute(['uid' => $user['id']]);
        $rows = array_map(function ($r) {
            $r['destinations'] = $r['destinations'] ? json_decode($r['destinations'], true) : [];
            $r['details']      = $r['details'] ? json_decode($r['details'], true) : null;
            return $r;
        }, $stmt->fetchAll());
        respond(['success' => true, 'data' => $rows]);
        break;

    case 'POST':
        $body = getJsonBody();
        $stmt = $db->prepare('INSERT INTO saved_plans
            (user_id, title, destinations, depart_date, retour_date, travelers, trip_type, budget_level, total_price, details)
            VALUES (:uid, :title, :dests, :dep, :ret, :trav, :type, :budget, :total, :details)');
        $stmt->execute([
            'uid'    => $user['id'],
            'title'  => $body['title'] ?? 'Mon voyage sur mesure',
            'dests'  => json_encode($body['destinations'] ?? []),
            'dep'    => $body['depart_date'] ?? null,
            'ret'    => $body['retour_date'] ?? null,
            'trav'   => (int)($body['travelers'] ?? 1),
            'type'   => $body['trip_type'] ?? null,
            'budget' => $body['budget_level'] ?? null,
            'total'  => $body['total_price'] ?? null,
            'details'=> json_encode($body['details'] ?? null),
        ]);
        respond(['success' => true, 'id' => (int)$db->lastInsertId()], 201);
        break;

    case 'DELETE':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) respondError('id requis.');
        $stmt = $db->prepare('DELETE FROM saved_plans WHERE id = :id AND user_id = :uid');
        $stmt->execute(['id' => $id, 'uid' => $user['id']]);
        respond(['success' => true]);
        break;

    default:
        respondError('Méthode non autorisée', 405);
}
