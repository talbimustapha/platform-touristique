<?php
/**
 * POST /api/newsletter.php   body: { email }
 */

require_once __DIR__ . '/../config/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respondError('Méthode non autorisée', 405);
}

$body  = getJsonBody();
$email = trim(strtolower($body['email'] ?? ''));

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respondError('Adresse email invalide.');
}

$db = getDB();
$stmt = $db->prepare('INSERT IGNORE INTO newsletter_subscribers (email) VALUES (:email)');
$stmt->execute(['email' => $email]);

respond(['success' => true, 'message' => 'Merci ! Vous êtes bien abonné(e) à notre newsletter.']);
