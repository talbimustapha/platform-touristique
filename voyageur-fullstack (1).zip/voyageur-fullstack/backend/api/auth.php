<?php
/**
 * POST /api/auth.php   body: { action: "register", full_name, email, password, phone? }
 * POST /api/auth.php   body: { action: "login", email, password }
 * POST /api/auth.php   body: { action: "logout" }
 * GET  /api/auth.php                -> retourne l'utilisateur connecté (ou null)
 */

require_once __DIR__ . '/../config/bootstrap.php';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (empty($_SESSION['user_id'])) {
        respond(['success' => true, 'user' => null]);
    }
    $stmt = $db->prepare('SELECT id, full_name, email, phone, newsletter_opt, created_at FROM users WHERE id = :id');
    $stmt->execute(['id' => $_SESSION['user_id']]);
    $user = $stmt->fetch();
    respond(['success' => true, 'user' => $user ?: null]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respondError('Méthode non autorisée', 405);
}

$body   = getJsonBody();
$action = $body['action'] ?? '';

switch ($action) {

    case 'register':
        $fullName = trim($body['full_name'] ?? '');
        $email    = trim(strtolower($body['email'] ?? ''));
        $password = $body['password'] ?? '';
        $phone    = trim($body['phone'] ?? '');
        $nl       = !empty($body['newsletter']) ? 1 : 0;

        if (!$fullName || !$email || !$password) {
            respondError('Nom, email et mot de passe sont requis.');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            respondError('Adresse email invalide.');
        }
        if (strlen($password) < 6) {
            respondError('Le mot de passe doit contenir au moins 6 caractères.');
        }

        $stmt = $db->prepare('SELECT id FROM users WHERE email = :email');
        $stmt->execute(['email' => $email]);
        if ($stmt->fetch()) {
            respondError('Un compte existe déjà avec cet email.', 409);
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $db->prepare('INSERT INTO users (full_name, email, password_hash, phone, newsletter_opt) VALUES (:n, :e, :p, :ph, :nl)');
        $stmt->execute(['n' => $fullName, 'e' => $email, 'p' => $hash, 'ph' => $phone ?: null, 'nl' => $nl]);

        $userId = (int)$db->lastInsertId();
        $_SESSION['user_id']    = $userId;
        $_SESSION['user_email'] = $email;

        respond(['success' => true, 'user' => ['id' => $userId, 'full_name' => $fullName, 'email' => $email]], 201);
        break;

    case 'login':
        $email    = trim(strtolower($body['email'] ?? ''));
        $password = $body['password'] ?? '';

        if (!$email || !$password) {
            respondError('Email et mot de passe sont requis.');
        }

        $stmt = $db->prepare('SELECT * FROM users WHERE email = :email');
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            respondError('Email ou mot de passe incorrect.', 401);
        }

        $_SESSION['user_id']    = (int)$user['id'];
        $_SESSION['user_email'] = $user['email'];

        unset($user['password_hash']);
        respond(['success' => true, 'user' => $user]);
        break;

    case 'logout':
        $_SESSION = [];
        session_destroy();
        respond(['success' => true]);
        break;

    default:
        respondError('Action inconnue. Utilisez register, login ou logout.');
}
