<?php
/**
 * GET  /api/bookings.php        -> liste des réservations de l'utilisateur connecté
 * POST /api/bookings.php  body: { destination_id?, package_title, full_name, email,
 *                                  phone?, travel_date?, travelers? }
 * PUT  /api/bookings.php  body: { id, status }   -> mise à jour du statut (admin)
 */

require_once __DIR__ . '/../config/bootstrap.php';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $user = requireAuth();
    $stmt = $db->prepare('SELECT b.*, d.title AS destination_title FROM bookings b
                           LEFT JOIN destinations d ON d.id = b.destination_id
                           WHERE b.user_id = :uid ORDER BY b.created_at DESC');
    $stmt->execute(['uid' => $user['id']]);
    respond(['success' => true, 'data' => $stmt->fetchAll()]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = getJsonBody();

    $packageTitle = trim($body['package_title'] ?? '');
    $fullName     = trim($body['full_name'] ?? '');
    $email        = trim($body['email'] ?? '');
    $phone        = trim($body['phone'] ?? '');
    $travelDate   = $body['travel_date'] ?? null;
    $travelers    = (int)($body['travelers'] ?? 1);
    $destId       = !empty($body['destination_id']) ? (int)$body['destination_id'] : null;

    if (!$packageTitle || !$fullName || !$email) {
        respondError('Le titre du voyage, le nom complet et l\'email sont requis.');
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        respondError('Adresse email invalide.');
    }

    $userId = $_SESSION['user_id'] ?? null;

    $stmt = $db->prepare('INSERT INTO bookings
        (user_id, destination_id, package_title, full_name, email, phone, travel_date, travelers)
        VALUES (:uid, :did, :title, :name, :email, :phone, :date, :travelers)');
    $stmt->execute([
        'uid'       => $userId,
        'did'       => $destId,
        'title'     => $packageTitle,
        'name'      => $fullName,
        'email'     => $email,
        'phone'     => $phone ?: null,
        'date'      => $travelDate ?: null,
        'travelers' => $travelers,
    ]);

    respond(['success' => true, 'id' => (int)$db->lastInsertId(), 'message' => 'Réservation enregistrée. Notre équipe vous contactera sous 24h.'], 201);
}

if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $user = requireAuth();
    $body = getJsonBody();
    $id     = (int)($body['id'] ?? 0);
    $status = $body['status'] ?? '';
    if (!$id || !in_array($status, ['pending', 'confirmed', 'cancelled'], true)) {
        respondError('Paramètres invalides.');
    }
    $stmt = $db->prepare('UPDATE bookings SET status = :s WHERE id = :id AND user_id = :uid');
    $stmt->execute(['s' => $status, 'id' => $id, 'uid' => $user['id']]);
    respond(['success' => true]);
}

respondError('Méthode non autorisée', 405);
