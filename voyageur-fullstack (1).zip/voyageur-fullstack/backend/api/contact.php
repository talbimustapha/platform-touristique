<?php
/**
 * POST /api/contact.php   body: { name, email, subject?, message }
 */

require_once __DIR__ . '/../config/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respondError('Méthode non autorisée', 405);
}

$body    = getJsonBody();
$name    = trim($body['name'] ?? '');
$email   = trim($body['email'] ?? '');
$subject = trim($body['subject'] ?? '');
$message = trim($body['message'] ?? '');

if (!$name || !$email || !$message) {
    respondError('Nom, email et message sont requis.');
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respondError('Adresse email invalide.');
}

$db = getDB();
$stmt = $db->prepare('INSERT INTO contact_messages (name, email, subject, message) VALUES (:n, :e, :s, :m)');
$stmt->execute(['n' => $name, 'e' => $email, 's' => $subject ?: null, 'm' => $message]);

respond(['success' => true, 'message' => 'Votre message a bien été envoyé. Réponse sous 2h.'], 201);
