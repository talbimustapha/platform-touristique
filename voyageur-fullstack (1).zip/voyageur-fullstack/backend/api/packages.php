<?php
/**
 * GET /api/packages.php                 -> tous les packages
 * GET /api/packages.php?tag=aventure    -> filtre par tag
 * GET /api/packages.php?destination=Marrakech -> filtre par ville
 * GET /api/packages.php?sort=asc|desc   -> tri par prix (désactivé côté front,
 *                                            disponible côté API pour usage futur)
 */

require_once __DIR__ . '/../config/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    respondError('Méthode non autorisée', 405);
}

$db = getDB();
$sql = 'SELECT * FROM packages WHERE 1=1';
$params = [];

if (!empty($_GET['destination'])) {
    $sql .= ' AND destination_name LIKE :dest';
    $params['dest'] = '%' . $_GET['destination'] . '%';
}

$order = 'ORDER BY id ASC';
if (!empty($_GET['sort'])) {
    if ($_GET['sort'] === 'asc')  $order = 'ORDER BY price ASC';
    if ($_GET['sort'] === 'desc') $order = 'ORDER BY price DESC';
}
$sql .= ' ' . $order;

$stmt = $db->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$rows = array_map(function ($r) {
    $r['id']    = (int)$r['id'];
    $r['days']  = (int)$r['days'];
    $r['price'] = (float)$r['price'];
    $r['tags']  = $r['tags'] ? json_decode($r['tags'], true) : [];
    return $r;
}, $rows);

// filtre tag côté PHP (JSON_CONTAINS nécessite MySQL 5.7+, ok mais on reste simple)
if (!empty($_GET['tag']) && $_GET['tag'] !== 'all') {
    $tag = $_GET['tag'];
    $rows = array_values(array_filter($rows, fn($r) => in_array($tag, $r['tags'])));
}

respond(['success' => true, 'data' => $rows]);
