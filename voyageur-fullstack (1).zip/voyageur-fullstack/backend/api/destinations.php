<?php
/**
 * GET /api/destinations.php            -> liste toutes les destinations
 * GET /api/destinations.php?id=1       -> détail d'une destination
 * GET /api/destinations.php?category=imperial -> filtre par catégorie
 */

require_once __DIR__ . '/../config/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    respondError('Méthode non autorisée', 405);
}

$db = getDB();

function decodeRow(array $row): array {
    foreach (['highlights', 'food', 'program', 'includes'] as $field) {
        $row[$field] = $row[$field] ? json_decode($row[$field], true) : [];
    }
    $row['medina'] = $row['medina_name'] ? [
        'name'    => $row['medina_name'],
        'founded' => $row['medina_founded'],
        'text'    => $row['medina_text'],
    ] : null;
    unset($row['medina_name'], $row['medina_founded'], $row['medina_text']);
    $row['id']    = (int)$row['id'];
    $row['days']  = (int)$row['days'];
    $row['price'] = (float)$row['price'];
    return $row;
}

if (!empty($_GET['id'])) {
    $stmt = $db->prepare('SELECT * FROM destinations WHERE id = :id');
    $stmt->execute(['id' => (int)$_GET['id']]);
    $row = $stmt->fetch();
    if (!$row) respondError('Destination introuvable', 404);
    respond(['success' => true, 'data' => decodeRow($row)]);
}

$sql = 'SELECT * FROM destinations';
$params = [];
if (!empty($_GET['category']) && $_GET['category'] !== 'all') {
    $sql .= ' WHERE category = :category';
    $params['category'] = $_GET['category'];
}
$sql .= ' ORDER BY id ASC';

$stmt = $db->prepare($sql);
$stmt->execute($params);
$rows = array_map('decodeRow', $stmt->fetchAll());

respond(['success' => true, 'data' => $rows]);
