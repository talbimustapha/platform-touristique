<?php
/**
 * GET    /api/wishlist.php            -> liste des favoris de l'utilisateur
 * POST   /api/wishlist.php  body:{destination_id} -> ajouter aux favoris
 * DELETE /api/wishlist.php?destination_id=1        -> retirer des favoris
 */

require_once __DIR__ . '/../config/bootstrap.php';

$db   = getDB();
$user = requireAuth();

switch ($_SERVER['REQUEST_METHOD']) {

    case 'GET':
        $stmt = $db->prepare('SELECT w.id AS wishlist_id, d.* FROM wishlist w
                               JOIN destinations d ON d.id = w.destination_id
                               WHERE w.user_id = :uid ORDER BY w.created_at DESC');
        $stmt->execute(['uid' => $user['id']]);
        respond(['success' => true, 'data' => $stmt->fetchAll()]);
        break;

    case 'POST':
        $body  = getJsonBody();
        $destId = (int)($body['destination_id'] ?? 0);
        if (!$destId) respondError('destination_id requis.');

        $stmt = $db->prepare('INSERT IGNORE INTO wishlist (user_id, destination_id) VALUES (:uid, :did)');
        $stmt->execute(['uid' => $user['id'], 'did' => $destId]);
        respond(['success' => true], 201);
        break;

    case 'DELETE':
        $destId = (int)($_GET['destination_id'] ?? 0);
        if (!$destId) respondError('destination_id requis.');

        $stmt = $db->prepare('DELETE FROM wishlist WHERE user_id = :uid AND destination_id = :did');
        $stmt->execute(['uid' => $user['id'], 'did' => $destId]);
        respond(['success' => true]);
        break;

    default:
        respondError('Méthode non autorisée', 405);
}
