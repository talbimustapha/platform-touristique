# Voyageur.ma — Site Complet (Frontend + Backend PHP/MySQL + API)

## 📁 Structure du projet

```
voyageur-fullstack/
├── frontend/               # Site (HTML/CSS/JS) — ce que voit le visiteur
│   ├── index.html
│   ├── style.css
│   └── script.js           # contient le client API (objet `api`) tout en haut
├── backend/
│   ├── config/
│   │   ├── database.php    # connexion PDO — à configurer (host/user/pass)
│   │   └── bootstrap.php   # CORS, session, helpers JSON
│   ├── api/
│   │   ├── destinations.php   GET  liste / détail des 12 destinations
│   │   ├── packages.php       GET  résultats du moteur de recherche
│   │   ├── auth.php           POST register / login / logout · GET utilisateur connecté
│   │   ├── bookings.php       GET/POST/PUT  réservations
│   │   ├── wishlist.php       GET/POST/DELETE  favoris
│   │   ├── plans.php          GET/POST/DELETE  plans de voyage sauvegardés
│   │   ├── newsletter.php     POST  inscription newsletter
│   │   └── contact.php        POST  messages de contact
│   └── .htaccess
└── database/
    └── schema.sql          # tables + données de départ (12 destinations, packages)
```

## 📤 Mettre le projet sur GitHub

Le dossier est déjà initialisé en dépôt Git localement (`git init`), avec un
`.gitignore` qui exclut `backend/config/database.php` (vos identifiants
MySQL réels) — c'est `database.example.php` qui est versionné à la place.

1. Créez un nouveau dépôt (vide, sans README) sur https://github.com/new
2. Depuis le dossier du projet :
   ```bash
   git add .
   git commit -m "Site Voyageur.ma - frontend + backend PHP/MySQL + API"
   git branch -M main
   git remote add origin https://github.com/VOTRE-USER/VOTRE-DEPOT.git
   git push -u origin main
   ```
3. Une fois cloné ailleurs, un collaborateur doit faire :
   ```bash
   cp backend/config/database.example.php backend/config/database.php
   # puis éditer database.php avec ses propres identifiants MySQL
   mysql -u root -p < database/schema.sql
   ```

## 🚀 Installation (XAMPP / WAMP / MAMP / serveur PHP local)

### 1. Base de données
1. Démarrez MySQL (via phpMyAdmin ou en ligne de commande).
2. Importez le schéma :
   ```bash
   mysql -u root -p < database/schema.sql
   ```
   Cela crée la base `voyageur_db`, toutes les tables, et insère les 12
   destinations + les packages de démonstration déjà présents sur le site.

### 2. Backend PHP
1. Copiez le dossier `backend/` dans votre serveur (ex: `htdocs/voyageur/backend`
   pour XAMPP, ou `www/voyageur/backend` pour WAMP).
2. Ouvrez `backend/config/database.php` et adaptez si besoin :
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'voyageur_db');
   define('DB_USER', 'root');
   define('DB_PASS', '');   // votre mot de passe MySQL
   ```
3. Testez un endpoint dans le navigateur :
   `http://localhost/voyageur/backend/api/destinations.php`
   → vous devez voir un JSON avec les 12 destinations.

### 3. Frontend
1. Copiez `frontend/` à côté de `backend/` (ex: `htdocs/voyageur/frontend`).
2. Dans `frontend/script.js`, la constante tout en haut du fichier définit
   l'adresse de l'API :
   ```js
   const API_BASE = '/backend/api';
   ```
   Adaptez ce chemin selon l'URL réelle de votre dossier `backend/api`
   (ex: `/voyageur/backend/api` si vous avez un sous-dossier `voyageur`).
3. Ouvrez `http://localhost/voyageur/frontend/index.html` dans votre navigateur.

> 💡 Pour du développement rapide en local sans Apache/Nginx, vous pouvez
> aussi lancer le serveur intégré de PHP depuis la racine du projet :
> `php -S localhost:8000` puis servir le frontend avec un second serveur,
> ou tout regrouper sous un seul vhost Apache pointant sur ce dossier.

## 🔌 Ce qui est déjà branché à l'API (fonctionnel dès l'installation)

- **Destinations & packages** : chargés depuis MySQL au démarrage de la page
  (`loadDataFromBackend()` en bas de `script.js`). Si le backend n'est pas
  encore accessible, le site continue de fonctionner avec les données de
  démonstration codées en dur, en attendant.
- **Inscription / Connexion / Déconnexion** : `handleRegister()`,
  `handleLogin()`, `logoutUser()` appellent `api.register()`, `api.login()`,
  `api.logout()` → création réelle de compte (mot de passe haché avec
  `password_hash`), session PHP réelle (cookie).
- **Réservations** : `bookTrip()` enregistre une vraie ligne dans la table
  `bookings` via `api.createBooking()`.
- **Newsletter** : `subscribeNewsletter()` insère l'email dans
  `newsletter_subscribers` via `api.subscribeNewsletterApi()`.
- **Favoris (wishlist)** : `toggleDashWishlist()` / `removeFromWishlist()`
  synchronisent la table `wishlist` via `api.addWishlist()` /
  `api.removeWishlist()`.
- **Plans de voyage sauvegardés** : `savePlan()` enregistre le plan dans
  `saved_plans` via `api.savePlanApi()`.

## 🛠️ Pour aller plus loin (prochaines étapes suggérées)

Le tableau de bord (réservations, favoris, plans affichés dans l'espace
utilisateur) lit encore ses données depuis `localStorage` pour un rendu
instantané. Le client API (`api.myBookings()`, `api.getWishlist()`,
`api.getPlans()`) existe déjà dans `script.js` — il suffit de remplacer les
lectures `getDashBookings()` / `getDashWishlist()` / `getSavedPlans()` par
des appels `await api.myBookings()` etc. pour que le tableau de bord soit
alimenté à 100% par MySQL plutôt que par le navigateur.

Autres pistes :
- Ajouter un espace admin PHP pour gérer les destinations/réservations.
- Passer l'API en JWT si vous prévoyez une app mobile en plus du site web.
- Envoyer un vrai email (PHPMailer) à la création d'une réservation/contact.
- Ajouter la pagination + un vrai filtre plein-texte sur `packages.php`.

## 🔐 Sécurité déjà en place

- Mots de passe hachés avec `password_hash()` / vérifiés avec
  `password_verify()` — jamais stockés en clair côté serveur.
- Requêtes SQL 100% préparées (PDO, `PDO::ATTR_EMULATE_PREPARES => false`).
- Sessions PHP côté serveur pour l'authentification (cookie `httpOnly`
  géré nativement par PHP).
- Validation des emails et des champs obligatoires sur chaque endpoint.

## 📝 Notes

- Filtres de tri "Moins cher" / "Plus cher" désactivés dans l'interface de
  recherche (visuellement grisés, non cliquables) suite à votre demande —
  l'API `packages.php?sort=asc|desc` reste disponible si vous voulez les
  réactiver plus tard.
- Les 12 destinations en base incluent déjà les sections **Médina
  Historique** et **Spécialités Culinaires** (colonnes JSON `medina_*` et
  `food`).
